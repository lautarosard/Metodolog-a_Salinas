﻿using System;

namespace Ejercicio8
{
	/// <summary>
	/// Description of IOrdenable.
	/// </summary>
	public interface IOrdenable
	{
		setOrdenInicio(OrdenEnAula1 OA1);
		setOrdenLlegaAlumno(OrdenEnAula2 OA2);
		setOrdenAulaLlena(OrdenEnAula1 OA1);
	}
}
