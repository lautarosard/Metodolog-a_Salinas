﻿/*
 * User: lauta
 * Date: 28/9/2024
 */
using System;

namespace Ejercicio8
{
	/// <summary>
	/// Description of OrdenEnAula2.
	/// </summary>
	public interface OrdenEnAula2
	{
		void ejecutar(IAlumno alu);
	}
}
