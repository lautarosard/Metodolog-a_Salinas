﻿/*
 * User: lauta
 * Date: 28/9/2024
 */
using System;

namespace Ejercicio9
{
	/// <summary>
	/// Description of OrdenEnAula1.
	/// </summary>
	public interface OrdenEnAula1
	{
		void ejecutar();
	}
}
