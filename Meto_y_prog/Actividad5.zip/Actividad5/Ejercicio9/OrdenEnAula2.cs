﻿/*
 * User: lauta
 * Date: 28/9/2024
 */
using System;

namespace Ejercicio9
{
	/// <summary>
	/// Description of OrdenEnAula2.
	/// </summary>
	public interface OrdenEnAula2
	{
		void ejecutar(IComparable);
	}
}
