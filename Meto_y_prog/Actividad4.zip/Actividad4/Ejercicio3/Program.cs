﻿/*
 * User: lauta
 * Date: 14/9/2024
 */
using System;
using Ejercicio3
	
namespace Ejercicio3
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}