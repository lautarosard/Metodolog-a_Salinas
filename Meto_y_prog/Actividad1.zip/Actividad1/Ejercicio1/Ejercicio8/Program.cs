﻿/*
 * Created by SharpDevelop.
 * User: lauta
 * Date: 31/08/2024
 * Time: 08:53 p. m.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace Ejercicio8
{
	class Program
	{
		
		public static void Main(string[] args)
		{
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
		
		
	}
}