﻿/*
 * User: lauta
 * Date: 14/9/2024
 */
using System;

namespace Ejercicio4
{
	/// <summary>
	/// Description of FabricaDePersonas.
	/// </summary>
	public class FabricaDePersonas
	{
		public FabricaDePersonas()
		{
		}
	}
}
