﻿/*
 * User: lauta
 * Date: 14/9/2024
 */
using System;

namespace Ejercicio6
{
	/// <summary>
	/// Description of FabricaDePersonas.
	/// </summary>
	public class FabricaDePersonas
	{
		public FabricaDePersonas()
		{
		}
	}
}
